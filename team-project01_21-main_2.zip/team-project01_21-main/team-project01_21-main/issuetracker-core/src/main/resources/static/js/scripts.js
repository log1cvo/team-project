document.addEventListener('DOMContentLoaded', () => {
    const ticketsTable = document.getElementById('tickets-table');

    if (ticketsTable) {
        fetch('/api/tickets')
            .then(response => response.json())
            .then(ticketsData => {
                const tbody = ticketsTable.querySelector('tbody');
                ticketsData.forEach(ticket => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${ticket.priority}</td>
                        <td>${ticket.ticketId}</td>
                        <td>${ticket.contact}</td>
                        <td>${ticket.location}</td>
                        <td>${ticket.subject}</td>
                        <td>${ticket.category}</td>
                        <td>${ticket.assignedTo}</td>
                        <td>${ticket.status}</td>
                        <td>${ticket.createdDate}</td>
                    `;
                    tbody.appendChild(row);
                });
            })
            .catch(error => {
                console.error('Error fetching tickets:', error);
            });
    }

    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const ticketForm = document.getElementById('ticket-form');

    if (loginForm) {
        loginForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const username = event.target.username.value;
            const password = event.target.password.value;
            console.log('login:', { username, password });
        });
    }

    if (registerForm) {
        registerForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const username = event.target.username.value;
            const password = event.target.password.value;
            const email = event.target.email.value;
            console.log('register:', { username, password, email });
        });
    }

    if (ticketForm) {
        ticketForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const ticket = {
                priority: event.target.priority.value,
                ticketId: event.target.ticketId.value,
                contact: event.target.contact.value,
                location: event.target.location.value,
                subject: event.target.subject.value,
                category: event.target.category.value,
                assignedTo: event.target.assignedTo.value,
                status: event.target.status.value,
                createdDate: new Date(event.target.createdDate.value).toISOString()
            };

            fetch('/api/tickets', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(ticket)
            })
            .then(response => response.json())
            .then(data => {
                console.log('Ticket created:', data);

                const tbody = ticketsTable.querySelector('tbody');
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${data.priority}</td>
                    <td>${data.ticketId}</td>
                    <td>${data.contact}</td>
                    <td>${data.location}</td>
                    <td>${data.subject}</td>
                    <td>${data.category}</td>
                    <td>${data.assignedTo}</td>
                    <td>${data.status}</td>
                    <td>${data.createdDate}</td>
                `;
                tbody.appendChild(row);

                ticketForm.reset();
            })
            .catch(error => {
                console.error('Error creating ticket:', error);
            });
        });
    }
});