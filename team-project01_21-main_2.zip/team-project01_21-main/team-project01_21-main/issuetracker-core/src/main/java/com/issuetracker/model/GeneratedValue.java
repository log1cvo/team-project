package com.issuetracker.model;

public @interface GeneratedValue {

}
