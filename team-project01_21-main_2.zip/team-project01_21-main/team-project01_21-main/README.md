# team-project

# Issue Management System

## Introduction 
this project is come from program eng 01 team21.
엽준성 20213541
양호신(20195#98)
허호(20225#58)

## Features
- **User Management**: Register, login, and manage user profiles.
- **Issue Tracking**: Create, update, and track issues with detailed status reports.
- **Comments**: Add comments to issues to facilitate discussion among team members.
- **Role-Based Access**: Different access levels for admins, project managers, developers, and testers.
- **Statistics**: Visualize issue statistics to monitor project health and team productivity.


## Installation
**Clone the repository**:
   ```bash
   git clone https://github.com/yourusername/issue-management-system.git
   cd issue-management-system