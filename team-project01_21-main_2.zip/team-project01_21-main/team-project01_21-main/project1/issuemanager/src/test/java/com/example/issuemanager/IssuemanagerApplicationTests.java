package com.example.issuemanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IssuemanagerApplicationTests {

    @Test
    void contextLoads() {
    }

}
