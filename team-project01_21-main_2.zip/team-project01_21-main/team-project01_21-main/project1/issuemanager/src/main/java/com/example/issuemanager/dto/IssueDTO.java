package com.example.issuemanager.dto;

public class IssueDTO {
}
