package com.issuetracker.controller;

import com.issuetracker.model.Issue;
import com.issuetracker.service.IssueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/issues")
public class IssueViewController {

    @Autowired
    private IssueService issueService;

    @GetMapping
    public String getAllIssues(Model model) {
        List<Issue> issues = issueService.getAllIssues();
        model.addAttribute("issues", issues);
        return "issues";
    }
}